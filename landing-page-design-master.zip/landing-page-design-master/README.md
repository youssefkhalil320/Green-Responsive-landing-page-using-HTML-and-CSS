# Main Colors:

Dark #3E3E3E

Gray #EAEAEA

# Links & Attributions

Fontawesome - https://fontawesome.com/

Google Fonts - https://fonts.google.com/ (Font is called Poppins)

Waves - https://getwaves.io/

Freepik: https://www.freepik.com/free-vector/messages-concept-illustration_5911276.htm#page=1&query=messages&position=14

https://www.freepik.com/vectors/box Box vector created by stories - www.freepik.com
